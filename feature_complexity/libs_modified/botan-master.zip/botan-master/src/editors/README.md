# Editor Configurations

Those editor configurations and/or project files can be used to set up your favourite editor for developing Botan.
To enable any of those, just symlink the respective files into the repository root.
